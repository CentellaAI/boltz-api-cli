from app.analysis.protein_protein import compute_buried_surface_area

# Replace with a PROTEIN–PROTEIN job ID (two chains present)
cif_path = (
    "/tmp/boltz_jobs/a55f74b4a5fb46b7937345d604d0783f/"
    "outputs/boltz_results_input/predictions/input/input_model_0.cif"
)

if __name__ == "__main__":
    result = compute_buried_surface_area(cif_path)
    print(result)
